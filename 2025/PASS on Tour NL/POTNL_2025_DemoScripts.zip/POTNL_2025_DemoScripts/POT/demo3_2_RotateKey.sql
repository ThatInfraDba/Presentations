-- Step 1: Create a new Master Key in the master database
USE master;
GO

CREATE CERTIFICATE TDECert_New
WITH SUBJECT = 'New TDE Certificate';
GO

-- Step 2: Alter the database encryption key
USE [POTNLTDE];
GO

ALTER DATABASE ENCRYPTION KEY
ENCRYPTION BY SERVER CERTIFICATE TDECert_New;
GO

-- Step 3: Verify the newly bound certificate
USE [master]
GO 

SELECT 
    db.name AS DatabaseName,
    dek.encryption_state,
    CASE dek.encryption_state
        WHEN 0 THEN 'No encryption'
        WHEN 1 THEN 'Unencrypted'
        WHEN 2 THEN 'Encryption in progress'
        WHEN 3 THEN 'Encrypted'
        WHEN 4 THEN 'Key change in progress'
        WHEN 5 THEN 'Decryption in progress'
        WHEN 6 THEN 'Protection change in progress'
    END AS EncryptionStatus,
    dek.encryptor_type,
    dek.encryptor_thumbprint
FROM sys.databases db
JOIN sys.dm_database_encryption_keys dek
    ON db.database_id = dek.database_id
WHERE db.name = 'POTNLTDE';


SELECT name,
       thumbprint
FROM sys.certificates WHERE name LIKE 'TDECert%';