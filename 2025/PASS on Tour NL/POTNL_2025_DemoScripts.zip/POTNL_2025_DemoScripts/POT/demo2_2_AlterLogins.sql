-- Connect as Impersonate

-- Let's try to change the password of the users

USE [master];
GO

ALTER LOGIN [impersonate2] WITH PASSWORD = N'POTNL2025';
GO


USE [master];
GO

ALTER LOGIN [controlserver] WITH PASSWORD = N'POTNL2025';
GO


-- You can only change the password for a login with explicit "impersonate any login" 