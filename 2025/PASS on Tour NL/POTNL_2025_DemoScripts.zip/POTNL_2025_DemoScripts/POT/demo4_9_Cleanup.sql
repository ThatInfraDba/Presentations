USE master
GO
ALTER SERVER AUDIT SPECIFICATION [AccountModificationSpecification] WITH (STATE = OFF)
ALTER SERVER AUDIT [AccountModification] WITH (STATE = OFF)
DROP SERVER AUDIT [AccountModification]
DROP SERVER AUDIT SPECIFICATION [AccountModificationSpecification]
ALTER SERVER AUDIT SPECIFICATION [UserObjectModificationSpecification] WITH (STATE = OFF)
ALTER SERVER AUDIT [UserObjectModification] WITH (STATE = OFF)
DROP SERVER AUDIT [UserObjectModification]
DROP SERVER AUDIT SPECIFICATION [UserObjectModificationSpecification]
ALTER SERVER AUDIT SPECIFICATION [ServerPermissionsSpecification] WITH (STATE = OFF)
ALTER SERVER AUDIT [ServerPermissions] WITH (STATE = OFF)
DROP SERVER AUDIT [ServerPermissions]
DROP SERVER AUDIT SPECIFICATION [ServerPermissionsSpecification]
USE msdb
ALTER DATABASE AUDIT SPECIFICATION [ServerConfigurationSpecification_msdb] WITH (STATE = OFF)
USE master
ALTER DATABASE AUDIT SPECIFICATION [ServerConfigurationSpecification_master] WITH (STATE = OFF)
ALTER SERVER AUDIT [ServerConfiguration] WITH (STATE = OFF)
DROP SERVER AUDIT [ServerConfiguration]
USE master DROP DATABASE AUDIT SPECIFICATION [ServerConfigurationSpecification_Master]
USE msdb DROP DATABASE AUDIT SPECIFICATION [ServerConfigurationSpecification_msdb]

USE [POTNL]
DROP TABLE dbo.Example