-- Clean up
USE master
GO
alter database [POTNLTDE] set single_user with rollback immediate
DROP DATABASE [POTNLTDE];
DROP CERTIFICATE TDECert
DROP CERTIFICATE TDECert_New
DROP MASTER KEY 