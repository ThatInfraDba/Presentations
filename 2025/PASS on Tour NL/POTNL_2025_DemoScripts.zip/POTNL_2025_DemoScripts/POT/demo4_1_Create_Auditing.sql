USE	[master]
GO
/* Account Modification */
IF EXISTS (SELECT 1 FROM sys.server_audits WHERE name = 'AccountModification')
BEGIN
	ALTER SERVER AUDIT SPECIFICATION [AccountModificationSpecification] WITH (STATE = OFF)
	ALTER SERVER AUDIT [AccountModification] WITH (STATE = OFF)
	DROP SERVER AUDIT [AccountModification]
	DROP SERVER AUDIT SPECIFICATION [AccountModificationSpecification]
END
GO
CREATE SERVER AUDIT [AccountModification]
TO FILE 
(	FILEPATH = N'C:\Audits\'
	,MAXSIZE = 25 MB
	,MAX_ROLLOVER_FILES = 2147483647
	,RESERVE_DISK_SPACE = OFF
) WITH (QUEUE_DELAY = 1000, ON_FAILURE = CONTINUE)
ALTER SERVER AUDIT [AccountModification] WITH (STATE = OFF)
GO
CREATE SERVER AUDIT SPECIFICATION [AccountModificationSpecification]
FOR SERVER AUDIT [AccountModification]
ADD (DATABASE_PRINCIPAL_CHANGE_GROUP),
ADD (SERVER_PRINCIPAL_CHANGE_GROUP),
ADD (LOGIN_CHANGE_PASSWORD_GROUP),
ADD (USER_CHANGE_PASSWORD_GROUP)
WITH (STATE = OFF)
GO
ALTER SERVER AUDIT SPECIFICATION [AccountModificationSpecification] WITH (STATE = ON)
ALTER SERVER AUDIT [AccountModification] WITH (STATE = ON)
GO

/* Server Configuration */
IF EXISTS (SELECT 1 FROM sys.server_audits WHERE name = 'ServerConfiguration')
BEGIN
	USE msdb
	ALTER DATABASE AUDIT SPECIFICATION [ServerConfigurationSpecification_msdb] WITH (STATE = OFF)
	USE master
	ALTER DATABASE AUDIT SPECIFICATION [ServerConfigurationSpecification_master] WITH (STATE = OFF)
	ALTER SERVER AUDIT [ServerConfiguration] WITH (STATE = OFF)
	DROP SERVER AUDIT [ServerConfiguration]
	USE master DROP DATABASE AUDIT SPECIFICATION [ServerConfigurationSpecification_Master]
	USE msdb DROP DATABASE AUDIT SPECIFICATION [ServerConfigurationSpecification_msdb]
END
GO
USE master
GO
CREATE SERVER AUDIT [ServerConfiguration]
TO FILE 
(	FILEPATH = N'C:\Audits\'
	,MAXSIZE = 25 MB
	,MAX_ROLLOVER_FILES = 2147483647
	,RESERVE_DISK_SPACE = OFF
) WITH (QUEUE_DELAY = 1000, ON_FAILURE = CONTINUE)
ALTER SERVER AUDIT [ServerConfiguration] WITH (STATE = OFF)
GO
USE [master]
GO
CREATE DATABASE AUDIT SPECIFICATION [ServerConfigurationSpecification_Master]
FOR SERVER AUDIT [ServerConfiguration]
ADD (EXECUTE ON OBJECT::[sys].[sp_addserver] BY [dbo]),
ADD (EXECUTE ON OBJECT::[sys].[sp_setnetname] BY [dbo]),
ADD (EXECUTE ON OBJECT::[sys].[sp_addlinkedsrvlogin] BY [dbo]),
ADD (EXECUTE ON OBJECT::[sys].[sp_dropserver] BY [dbo]),
ADD (EXECUTE ON OBJECT::[sys].[sp_configure] BY [dbo]),
ADD (EXECUTE ON OBJECT::[sys].[sp_addlinkedserver] BY [dbo]),
ADD (EXECUTE ON OBJECT::[sys].[sp_droplinkedsrvlogin] BY [dbo]),
ADD (EXECUTE ON OBJECT::[sys].[sp_serveroption] BY [dbo])
WITH (STATE = OFF)
GO
USE [msdb]
GO
CREATE DATABASE AUDIT SPECIFICATION [ServerConfigurationSpecification_msdb]
FOR SERVER AUDIT [ServerConfiguration]
ADD (EXECUTE ON OBJECT::[dbo].[sp_stop_job] BY [dbo]),
ADD (EXECUTE ON OBJECT::[dbo].[sp_delete_job] BY [dbo]),
ADD (EXECUTE ON OBJECT::[dbo].[sp_update_job] BY [dbo]),
ADD (EXECUTE ON OBJECT::[dbo].[sp_add_job] BY [dbo]),
ADD (EXECUTE ON OBJECT::[dbo].[sp_delete_jobschedule] BY [dbo]),
ADD (EXECUTE ON OBJECT::[dbo].[sp_update_jobschedule] BY [dbo]),
ADD (EXECUTE ON OBJECT::[dbo].[sp_update_jobstep] BY [dbo]),
ADD (EXECUTE ON OBJECT::[dbo].[sp_add_jobstep] BY [dbo]),
ADD (EXECUTE ON OBJECT::[dbo].[sp_add_schedule] BY [dbo])
WITH (STATE = OFF)
GO
USE msdb
GO
ALTER DATABASE AUDIT SPECIFICATION [ServerConfigurationSpecification_msdb] WITH (STATE = ON)
USE master
GO
ALTER DATABASE AUDIT SPECIFICATION [ServerConfigurationSpecification_master] WITH (STATE = ON)
ALTER SERVER AUDIT [ServerConfiguration] WITH (STATE = ON)
GO

/* Server Permissions */
IF EXISTS (SELECT 1 FROM sys.server_audits WHERE name = 'ServerPermissions')
BEGIN
	ALTER SERVER AUDIT SPECIFICATION [ServerPermissionsSpecification] WITH (STATE = OFF)
	ALTER SERVER AUDIT [ServerPermissions] WITH (STATE = OFF)
	DROP SERVER AUDIT [ServerPermissions]
	DROP SERVER AUDIT SPECIFICATION [ServerPermissionsSpecification]
END
GO
CREATE SERVER AUDIT [ServerPermissions]
TO FILE 
(	FILEPATH = N'C:\Audits\'
	,MAXSIZE = 25 MB
	,MAX_ROLLOVER_FILES = 2147483647
	,RESERVE_DISK_SPACE = OFF
) WITH (QUEUE_DELAY = 1000, ON_FAILURE = CONTINUE)
ALTER SERVER AUDIT [ServerPermissions] WITH (STATE = OFF)
GO
CREATE SERVER AUDIT SPECIFICATION [ServerPermissionsSpecification]
FOR SERVER AUDIT [ServerPermissions]
ADD (SERVER_ROLE_MEMBER_CHANGE_GROUP),
ADD (SERVER_PERMISSION_CHANGE_GROUP),
ADD (SERVER_PRINCIPAL_IMPERSONATION_GROUP),
ADD (SERVER_PRINCIPAL_CHANGE_GROUP)
WITH (STATE = OFF)
GO
ALTER SERVER AUDIT SPECIFICATION [ServerPermissionsSpecification] WITH (STATE = ON)
ALTER SERVER AUDIT [ServerPermissions] WITH (STATE = ON)
GO

/* User Object Modification */
IF EXISTS (SELECT 1 FROM sys.server_audits WHERE name = 'UserObjectModification')
BEGIN
	ALTER SERVER AUDIT SPECIFICATION [UserObjectModificationSpecification] WITH (STATE = OFF)
	ALTER SERVER AUDIT [UserObjectModification] WITH (STATE = OFF)
	DROP SERVER AUDIT [UserObjectModification]
	DROP SERVER AUDIT SPECIFICATION [UserObjectModificationSpecification]
END
GO
CREATE SERVER AUDIT [UserObjectModification]
TO FILE 
(	FILEPATH = N'C:\Audits\'
	,MAXSIZE = 25 MB
	,MAX_ROLLOVER_FILES = 2147483647
	,RESERVE_DISK_SPACE = OFF
) WITH (QUEUE_DELAY = 1000, ON_FAILURE = CONTINUE)
ALTER SERVER AUDIT [UserObjectModification] WITH (STATE = OFF)
GO
CREATE SERVER AUDIT SPECIFICATION [UserObjectModificationSpecification]
FOR SERVER AUDIT [UserObjectModification]
ADD (SCHEMA_OBJECT_CHANGE_GROUP)
WITH (STATE = OFF)
GO
ALTER SERVER AUDIT SPECIFICATION [UserObjectModificationSpecification] WITH (STATE = ON)
ALTER SERVER AUDIT [UserObjectModification] WITH (STATE = ON)
GO