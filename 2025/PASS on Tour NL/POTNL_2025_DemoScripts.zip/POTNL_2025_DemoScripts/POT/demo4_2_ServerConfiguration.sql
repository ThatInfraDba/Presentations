-- Update system configuration for advanced options
EXEC sys.sp_configure @configname = 'show advanced options', -- varchar(35)
                 @configvalue = 1  -- int
GO
RECONFIGURE
GO
-- Update system configuration for CLR Enabled
EXEC sys.sp_configure @configname = 'clr enabled', -- varchar(35)
                 @configvalue = 1  -- int
GO
RECONFIGURE
GO
-- Update system configuration for CLR Strict to disabled
EXEC sys.sp_configure @configname = 'CLR Strict', -- varchar(35)
                 @configvalue = 0  -- int
GO
RECONFIGURE
GO

-- Take a look at the audit file
SELECT object_name, action_id, statement, additional_information, server_principal_name
FROM sys.fn_get_audit_file(
    'C:\\Audits\ServerConfiguration*.sqlaudit',
    DEFAULT,
    DEFAULT
) ORDER BY event_time desc;
GO
