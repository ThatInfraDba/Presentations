-- Clean up
USE master
GO
alter database [TDEDEMO] set single_user with rollback immediate
DROP DATABASE [TDEDEMO];
DROP CERTIFICATE TDECert
DROP CERTIFICATE TDECert_New
DROP MASTER KEY 