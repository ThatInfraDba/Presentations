-- Step 1: Create a Master Key in the master database
USE master;
GO

CREATE MASTER KEY ENCRYPTION BY PASSWORD = 'StrongPassword123!';
GO

-- Step 2: Create a Certificate to protect the Database Encryption Key
CREATE CERTIFICATE TDECert
WITH SUBJECT = 'TDE Certificate for TDEExample';
GO

-- Step 3: Create the database if it doesn't exist
IF DB_ID('TDEDEMO') IS NULL
BEGIN
    CREATE DATABASE TDEDEMO;
END;
GO

-- Step 4: Create a Database Encryption Key in TDEExample
USE [TDEDEMO];
GO

CREATE DATABASE ENCRYPTION KEY
WITH ALGORITHM = AES_256
ENCRYPTION BY SERVER CERTIFICATE TDECert;
GO

-- Step 5: Enable encryption
ALTER DATABASE [TDEDEMO] SET ENCRYPTION ON;

-- Step 6: Check on the encryption status
USE [master]
GO

SELECT percent_complete,
       encryption_state,
       DB_NAME(database_id) AS dbname
FROM sys.dm_database_encryption_keys;