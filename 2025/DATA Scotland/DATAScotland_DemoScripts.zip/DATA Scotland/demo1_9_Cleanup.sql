-- Clean-up demo

USE master;
GO

-- drop logins
DROP LOGIN impersonate;
DROP LOGIN impersonate2;
DROP LOGIN controlserver;

-- Switch back to Windows authentication
EXEC xp_instance_regwrite N'HKEY_LOCAL_MACHINE',
                          N'Software\Microsoft\MSSQLServer\MSSQLServer',
                          N'LoginMode',
                          REG_DWORD,
                          1;
GO