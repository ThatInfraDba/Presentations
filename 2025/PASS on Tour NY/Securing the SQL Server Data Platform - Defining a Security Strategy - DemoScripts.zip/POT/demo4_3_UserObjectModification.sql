-- Create a table in the POTNY database
USE [POTNY]
GO

CREATE TABLE dbo.Example
(
    id INT IDENTITY(1,1),
    first_name VARCHAR(256) NOT NULL,
    last_name VARCHAR(256) NOT NULL
);


-- Take a look at the audit file
SELECT object_name, action_id, statement, additional_information, server_principal_name
FROM sys.fn_get_audit_file(
    'C:\\Audits\UserObjectModification*.sqlaudit',
    DEFAULT,
    DEFAULT
) ORDER BY event_time desc;
GO

-- Add a column to the table
ALTER TABLE dbo.Example
ADD street VARCHAR(MAX) NOT NULL;

-- Take a look at the audit file again
SELECT object_name, action_id, statement, additional_information, server_principal_name
FROM sys.fn_get_audit_file(
    'C:\\Audits\UserObjectModification*.sqlaudit',
    DEFAULT,
    DEFAULT
) ORDER BY event_time desc;
GO