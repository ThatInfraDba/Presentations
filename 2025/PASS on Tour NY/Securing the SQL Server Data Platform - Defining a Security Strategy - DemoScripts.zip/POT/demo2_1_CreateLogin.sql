﻿-- Ensure we run in Mixed Mode for demo purposes
USE [master];
GO
-- Result should be 2
EXEC xp_instance_regread N'HKEY_LOCAL_MACHINE',
                         N'Software\Microsoft\MSSQLServer\MSSQLServer',
                         N'LoginMode';
GO

-- Change to mixed mode (2) if needed, remember to restart instance
--EXEC xp_instance_regwrite N'HKEY_LOCAL_MACHINE',
--                          N'Software\Microsoft\MSSQLServer\MSSQLServer',
--                          N'LoginMode',
--                          REG_DWORD,
--                          2;
--GO

USE [master];
GO
-- Create login who receives impersonate any login
CREATE LOGIN [impersonate]
WITH PASSWORD = N'impersonate123',
     DEFAULT_DATABASE = [master],
     DEFAULT_LANGUAGE = [us_english],
     CHECK_EXPIRATION = OFF,
     CHECK_POLICY = OFF;
GO

GRANT ALTER ANY LOGIN TO [impersonate];
GO

-- Create another login who receives impersonate any login
CREATE LOGIN [impersonate2]
WITH PASSWORD = N'impersonate2',
     DEFAULT_DATABASE = [master],
     CHECK_EXPIRATION = OFF,
     CHECK_POLICY = OFF;
GO
-- Grant privileges
GRANT IMPERSONATE ANY LOGIN TO [impersonate2];
GO


USE [master];
GO
-- Create login who receives control server
CREATE LOGIN [controlserver]
WITH PASSWORD = N'controlserver',
     DEFAULT_DATABASE = [master],
     CHECK_EXPIRATION = OFF,
     CHECK_POLICY = OFF;
GO
-- Grant privileges
GRANT CONTROL SERVER TO [controlserver];
GO
