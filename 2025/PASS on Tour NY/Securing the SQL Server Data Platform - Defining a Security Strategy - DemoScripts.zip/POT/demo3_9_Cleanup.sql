-- Clean up
USE master
GO
alter database [POTNYTDE] set single_user with rollback immediate
DROP DATABASE [POTNYTDE];
DROP CERTIFICATE TDECert
DROP CERTIFICATE TDECert_New
DROP MASTER KEY 