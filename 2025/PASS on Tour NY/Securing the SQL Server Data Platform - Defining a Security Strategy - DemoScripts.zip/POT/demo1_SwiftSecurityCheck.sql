/* ---------------------------------------------------
Script Author: Danny de Haan
Script Version: 0.5
Description:
This script will verify (basic) security settings.
To be used at the users discretion.
*/
---------------------------------------------------

-- Declare variables used throughout the script
DECLARE @SQLVersion VARCHAR(56);
DECLARE @SQLEdition VARCHAR(56);
-- Fill script variables
SET @SQLVersion = (SELECT CAST(SERVERPROPERTY('productversion') AS VARCHAR));
SET @SQLEdition = (SELECT CAST(SERVERPROPERTY('edition') AS VARCHAR));

SET NOCOUNT ON;
PRINT 'SQL Server: ' + @@SERVERNAME
-- Hide Instance 
DECLARE @HideInstanceValue INT;
EXEC xp_instance_regread 'HKEY_LOCAL_MACHINE',
                         'Software\Microsoft\Microsoft SQL Server\MSSQLServer\SuperSocketNetLib',
                         'HideInstance',
                         @HideInstanceValue OUTPUT;

PRINT 'Hide Instance Setting: ' + CASE WHEN @HideInstanceValue = 0 THEN 'Unhidden (advise: Hidden)' WHEN @HideInstanceValue = 1 THEN 'Hidden' ELSE 'Unknown' END;

-- Extended Protection 
DECLARE @ExtendedProtection INT;
EXEC xp_instance_regread 'HKEY_LOCAL_MACHINE',
                         'Software\Microsoft\Microsoft SQL Server\MSSQLServer\SuperSocketNetLib',
                         'ExtendedProtection',
                         @ExtendedProtection OUTPUT;

PRINT 'Extended Protection Value: ' + CASE WHEN @ExtendedProtection = 0 THEN 'Disabled (advise: Required)' WHEN @ExtendedProtection = 1 THEN 'Enabled' ELSE 'Unknown' END;

-- Force Encryption
DECLARE @ForceEncryption INT;
EXEC xp_instance_regread 'HKEY_LOCAL_MACHINE',
                         'Software\Microsoft\Microsoft SQL Server\MSSQLServer\SuperSocketNetLib',
                         'ForceEncryption',
                         @ForceEncryption OUTPUT;

PRINT 'Force Encryption Value: ' + CASE WHEN @ForceEncryption = 0 THEN 'Disabled (advice: Enabled)' WHEN @ForceEncryption = 1 THEN 'Enabled' ELSE 'Unknown' END;

-- RecoveryModel of model database
DECLARE @ModelRecoveryModel VARCHAR(10);
SELECT @ModelRecoveryModel = recovery_model_desc FROM sys.databases WHERE name = 'model';

PRINT 'Model Database Recovery Model: ' + @ModelRecoveryModel

-- RecoveryModel of msdb database
DECLARE @MsdbRecoveryModel VARCHAR(10);
SELECT @MsdbRecoveryModel = recovery_model_desc FROM sys.databases WHERE name = 'msdb';

PRINT 'MSDB Database Recovery Model: ' + @MsdbRecoveryModel

-- Remote Access Setting
DECLARE @RemoteAccess SQL_VARIANT;
SELECT @RemoteAccess = value_in_use FROM sys.configurations WHERE name = 'remote access'

PRINT 'Remote Access Setting: ' + CASE WHEN @RemoteAccess = 0 THEN 'Disabled' WHEN @RemoteAccess = 1 THEN 'Enabled (advise: Disabled)' ELSE 'Unknown' END;

-- Remote Admin Connection Setting
DECLARE @RemoteAdminConnection SQL_VARIANT;
SELECT @RemoteAdminConnection = value_in_use FROM sys.configurations WHERE name = 'remote admin connections'

PRINT 'Remote Admin Connection Setting: ' + CASE WHEN @RemoteAdminConnection = 0 THEN 'Disabled' WHEN @RemoteAdminConnection = 1 THEN 'Enabled (advise: Disabled)' ELSE 'Unknown' END;

-- Common Criteria Compliance Setting
IF @SQLEdition LIKE 'Enterprise%' OR @SQLEdition LIKE 'Developer%' 
BEGIN 
    DECLARE @CommonCriteriaCompliance SQL_VARIANT;
    SELECT @CommonCriteriaCompliance = value_in_use FROM sys.configurations WHERE name = 'common criteria compliance enabled'

    PRINT 'Common Criteria Compliance Setting: ' + CASE WHEN @CommonCriteriaCompliance = 0 THEN 'Disabled (advise: Enabled)' WHEN @CommonCriteriaCompliance = 1 THEN 'Enabled' ELSE 'Unknown' END;
END

-- sa account
DECLARE @saName VARCHAR(MAX);
SELECT @saName = name FROM sys.server_principals WHERE sid = 0x01

PRINT 'SA Account Name Status: ' + CASE WHEN @saName = 'sa' THEN 'Default (advise: Rename)' ELSE 'Renamed' END;

DECLARE @saState BIT;
SELECT @saState = is_disabled FROM sys.server_principals WHERE sid = 0x01

PRINT 'SA Account State: ' + CASE WHEN @saState = 1 THEN 'Disabled' WHEN @saState = 0 THEN 'Enabled (advise: Disabled)' ELSE 'Unknown' END;

-- Database Containment Setting
DECLARE @DatabaseContainment SQL_VARIANT;
SELECT @DatabaseContainment = value_in_use FROM sys.configurations WHERE name = 'contained database authentication'

PRINT 'Database Contained Authentication: ' + CASE WHEN @DatabaseContainment = 0 THEN 'Disabled (advise: Enabled)' WHEN @DatabaseContainment = 1 THEN 'Enabled' ELSE 'Unknown' END;

