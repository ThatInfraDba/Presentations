IF  EXISTS (SELECT 1 FROM sys.server_principals WHERE name = 'POT_LOGIN')
BEGIN
    DROP LOGIN POT_Login
END

CREATE LOGIN POT_Login WITH PASSWORD = 'StrongPassword123!'
GO

SELECT object_name, action_id, statement, additional_information, server_principal_name, *
FROM sys.fn_get_audit_file(
    'C:\\Audits\AccountModification*.sqlaudit',
    DEFAULT,
    DEFAULT
) ORDER BY event_time desc;
GO